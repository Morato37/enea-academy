/*
  Schnittform pro Selektionsposition

  Fügt der Tabelle mit den Positionen einer Projekt-Selektion (eine Zeile = eine Pflanze in einer Selektion)
  die Spalte pruning_form hinzu. Sie speichert den Code der gewählten Schnittform, z. B. 'hochstamm'.
  Der Katalog der Formen und die Skizzen liegen im Code (src/lib/pruningForms.ts).

  WICHTIG: Der Tabellenname "selection_items" ist ein Platzhalter.
  Bitte überall durch den echten Namen der Positionstabelle ersetzen.
*/

ALTER TABLE public.selection_items
  ADD COLUMN IF NOT EXISTS pruning_form text;

ALTER TABLE public.selection_items
  DROP CONSTRAINT IF EXISTS selection_items_pruning_form_check;

ALTER TABLE public.selection_items
  ADD CONSTRAINT selection_items_pruning_form_check CHECK (
    pruning_form IS NULL OR pruning_form IN (
      'hochstamm', 'halbstamm', 'mehrstaemmig', 'etagen', 'dach', 'kuppel', 'schirm',
      'hecke', 'spalier_u', 'spalier', 'bonsai', 'haenge', 'strauch', 'natur', 'solitaer'
    )
  );

COMMENT ON COLUMN public.selection_items.pruning_form IS
  'Gewählte Schnittform (Code aus src/lib/pruningForms.ts), NULL = noch nicht gewählt';

/*
  Falls es einen UNIQUE-Constraint auf (selection_id, plant_id) gibt, verhindert er, dass dieselbe Pflanze
  mit zwei Schnittformen in einer Selektion steht (z. B. 3 Platanen als Dachform und 5 als Hochstamm).
  Dann den Constraint durch diesen Index ersetzen (Namen anpassen):

  ALTER TABLE public.selection_items DROP CONSTRAINT <name_des_unique_constraints>;
  CREATE UNIQUE INDEX IF NOT EXISTS selection_items_selection_plant_form_key
    ON public.selection_items (selection_id, plant_id, COALESCE(pruning_form, ''));
*/
